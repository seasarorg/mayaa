package org.jaxen.pantry;

import java.io.StringReader;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jaxen.Context;
import org.jaxen.ContextSupport;
import org.jaxen.dom.DocumentNavigator;
import org.jaxen.pattern.Pattern;
import org.jaxen.pattern.PatternParser;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class Test {

static Node elem;
static Context context;
static {
try {
InputSource is = new InputSource( new StringReader( "<root> <a/><!-- --><b/><?pi ip?><b foo='bar'/></root>" ) );
Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse( is );
elem = doc.getDocumentElement().getLastChild();
System.out.println( "Current node is the last <"+ elem.getNodeName() +">" );
context = new Context( new ContextSupport( null, null, null, new DocumentNavigator() ) );
} catch (Exception e) { System.out.println("boo boo");}
}

    public static void main( String[] args ) throws Exception {
    
        // the troubles come here
        test("/root/b[1]");
        test("/root/b[2]");
        test("/root/*[1]");
        test("/root/*[2]");
        test("/root/*[3]");
        test("/root/node()[1]");
        test("/root/node()[5]");
        test("/root/node()[6]");
    }
    
    private static void test( String pattern ) throws Exception {
        Pattern p = PatternParser.parse( pattern );
        boolean b = p.matches( elem, context );
        System.out.println( b + " " + pattern );
    }

}